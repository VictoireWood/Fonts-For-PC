---
description: See what has changed each release.
---

# Changelog

### 

## 15.0.0 - 2042-12-0

### Fixed

* Removed humans, they weren't doing fine with animals.

### Changed

* Animals are now super cute, all of them.

## 14.0.0 - 2042-10-06

### Added

* Introduced animals into the world, we believe they're going to be a neat addition.



